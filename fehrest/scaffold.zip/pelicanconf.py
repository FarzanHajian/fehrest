#!/usr/bin/env python
# -*- coding: utf-8 -*- #

SITENAME = {{$$SiteName$$}}
SITESUBTITLE = ''

# Blogroll
LINKS = (
        ('Link 1', 'https://Link1.com/'),
        ('Link 2', 'https://www.Link2.org/'),
    )

FAVORITE_PAGES = [
        {'name':'List One', 'url':'/pages/list-one.html'},
        {'name':'List Two', 'url':'/pages/list-two.html'}
    ]

#################################################

DEFAULT_LANG = 'en'
THEME = 'themes/default'
TIMEZONE = 'Asia/Tehran'

#################################################

PATH = 'content'
STATIC_PATHS  = ['files']
DEFAULT_PAGINATION = False
DELETE_OUTPUT_DIRECTORY = True

# Feed generation is usually not desired when developing
FEED_ALL_ATOM = None
CATEGORY_FEED_ATOM = None
TRANSLATION_FEED_ATOM = None
AUTHOR_FEED_ATOM = None
AUTHOR_FEED_RSS = None



